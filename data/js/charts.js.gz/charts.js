/**
 * HyGrow IoT - Charting & Data Export Module
 * Handles high-performance Canvas API rendering and CSV generation.
 */

// Canvas fill/stroke styles can't reference CSS variables directly, so chart
// colors are resolved from the live theme tokens at draw time instead of
// being hardcoded. This keeps chart lines in sync with light/dark mode and
// with the app's single monochrome+two-accent color system (see style.css's
// :root/html.light token blocks) rather than duplicating separate hex
// values here that could drift out of sync with the theme.
function getThemeColor(varName, fallback) {
    const val = getComputedStyle(document.documentElement)
        .getPropertyValue(varName)
        .trim();
    return val || fallback;
}

// Named color roles used by chart lines — 'primary' for a chart's main/only
// series (was hardcoded #afc6ff blue), 'secondary' for a second series in a
// dual chart (was hardcoded #4edea3 green, reusing the app's one intentional
// green accent token). Resolves to an "r, g, b" triplet string so callers
// can build rgba() glow/gradient colors at any alpha.
function getChartColorRgb(role) {
    const varName = role === 'secondary' ? '--hg-secondary' : '--hg-on-background';
    const fallback = role === 'secondary' ? 'rgb(78, 222, 163)' : '#e1e1e1';
    const resolved = getThemeColor(varName, fallback);
    return hexOrRgbToRgbTriplet(resolved);
}

// Accepts '#rrggbb' or 'rgb(r, g, b)' / 'rgba(r, g, b, a)' and returns a
// plain 'r, g, b' string suitable for building new rgba(...) strings.
function hexOrRgbToRgbTriplet(color) {
    color = color.trim();
    if (color.startsWith('#')) {
        let hex = color.slice(1);
        if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
        const r = parseInt(hex.slice(0, 2), 16);
        const g = parseInt(hex.slice(2, 4), 16);
        const b = parseInt(hex.slice(4, 6), 16);
        return `${r}, ${g}, ${b}`;
    }
    const match = color.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/i);
    if (match) return `${match[1]}, ${match[2]}, ${match[3]}`;
    return '225, 225, 225'; // last-resort neutral fallback, never a brand hue
}

// Draws a standard single-value line chart with a gradient fill
function drawChart(context, cvs, dataArr, role) {
    if(!cvs || !cvs.width || !context) return;
    const w = cvs.width / window.devicePixelRatio;
    const h = cvs.height / window.devicePixelRatio;

    context.clearRect(0, 0, w, h);

    const rgb = getChartColorRgb(role);
    const colorStr = `rgb(${rgb})`;

    context.beginPath();
    context.strokeStyle = colorStr;
    context.lineWidth = 4;
    context.lineCap = 'round';
    context.lineJoin = 'round';

    // Guard divide-by-zero: with exactly one buffered point, length-1 is 0
    // and step becomes Infinity, which turns every x coordinate into NaN
    // and silently draws nothing. Falling back to width for a single point
    // is an arbitrary-but-harmless choice — there's nothing to connect a
    // single point to anyway.
    const step = w / Math.max(dataArr.length - 1, 1);
    const max = Math.max(...dataArr.filter(Number.isFinite), 10);
    let connected = false;

    dataArr.forEach((val, i) => {
        if (!Number.isFinite(val)) { connected = false; return; }
        const x = i * step;
        const y = h - ((val / max) * h * 0.8) - 20;
        if(!connected) context.moveTo(x, y);
        else context.lineTo(x, y);
        connected = true;
    });

    // Soft glow effect
    context.shadowBlur = 20;
    context.shadowColor = `rgba(${rgb}, 0.4)`;
    context.stroke();
    context.shadowBlur = 0;

    // Missing values break the line. A full-width fill would hide those gaps.
    if (!dataArr.length || dataArr.some(value => !Number.isFinite(value))) return;
    // Fill gradient under line
    context.lineTo(w, h);
    context.lineTo(0, h);
    context.closePath();

    const gradient = context.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, `rgba(${rgb}, 0.15)`);
    gradient.addColorStop(1, `rgba(${rgb}, 0)`);

    context.fillStyle = gradient;
    context.fill();
}

// Draws a dual-line chart (specifically for Air Temp & Humidity)
function drawDualChart(context, cvs, dataArr1, dataArr2) {
    if(!cvs || !cvs.width || !context) return;
    const w = cvs.width / window.devicePixelRatio;
    const h = cvs.height / window.devicePixelRatio;

    context.clearRect(0, 0, w, h);

    // Draw Data Array 1 (Humidity - Primary chart color)
    context.beginPath();
    context.strokeStyle = `rgb(${getChartColorRgb('primary')})`;
    context.lineWidth = 3;
    const step = w / Math.max(dataArr1.length - 1, 1); // see drawChart() for why Math.max guards against a single-point buffer
    let connected = false;

    dataArr1.forEach((val, i) => {
        if (!Number.isFinite(val)) { connected = false; return; }
        const x = i * step;
        const y = h - ((val / 100) * h * 0.8) - 20; // Scaled to 0-100%
        if(!connected) context.moveTo(x, y);
        else context.lineTo(x, y);
        connected = true;
    });
    context.stroke();

    // Draw Data Array 2 (Temp - Secondary chart color)
    context.beginPath();
    context.strokeStyle = `rgb(${getChartColorRgb('secondary')})`;
    context.lineWidth = 3;

    connected = false;
    dataArr2.forEach((val, i) => {
        if (!Number.isFinite(val)) { connected = false; return; }
        const x = i * step;
        const y = h - ((val / 50) * h * 0.8) - 20; // Scaled to 0-50°C
        if(!connected) context.moveTo(x, y);
        else context.lineTo(x, y);
        connected = true;
    });
    context.stroke();
}

// Exports a given array of data to a CSV file (Offline capability)
function exportSeriesToCsv(sensorName, dataArr) {
    if (!dataArr || dataArr.length === 0) {
        showAlertModal("No data available to export.");
        return;
    }

    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Reading Index,Value\n"; // Header

    dataArr.forEach((val, index) => {
        // Because we don't have NTP time yet, we use a simple reading index
        csvContent += `${index},${Number.isFinite(val) ? val.toFixed(2) : ''}\n`;
    });

    // Create a hidden link to trigger the download
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);

    // Timestamp for filename
    const date = new Date();
    const dateString = `${date.getFullYear()}${(date.getMonth()+1).toString().padStart(2, '0')}${date.getDate().toString().padStart(2, '0')}`;

    link.setAttribute("download", `hygrow_${sensorName}_${dateString}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
